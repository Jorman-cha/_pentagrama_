from flask import Flask, render_template
from flask_bootstrap import Bootstrap5 
from forms import LoginForm 
# Eliminada: 'from flask import config' ya que no es un objeto que se importe así.


app = Flask(__name__)
# Eliminada: 'app.config.from_object(config)' ya que era incorrecto.

# Configuración: Esto es suficiente para la mayoría de las apps pequeñas.
# (Necesario para formularios y seguridad de sesión)
app.config['SECRET_KEY'] = 'una-clave-secreta-larga' 

bootstrap = Bootstrap5(app)


# 3. RUTAS Y VISTAS

@app.route('/home')
@app.route('/')
def home():
    """Ruta para la página de inicio."""
    return render_template('index.html')

@app.route('/servicios')
def servicios():
    """Ruta para la página de servicios."""
    return render_template('servicios.html')

@app.route('/contacto')
def contacto():
    """Ruta para la página de servicios."""
    return render_template('contacto.html')


@app.route('/login')
def login():
    """Ruta para la página de inicio de sesión."""
    form = LoginForm()
    # Ahora pasamos el objeto 'form' al template 'login.html'
    return render_template('login.html', form=form)

# 4. MANEJO DE ERRORES

@app.errorhandler(404)
def page_not_found(e):
    """Manejador de error 404 (Página no encontrada)."""
    return render_template('404.html'), 404


# 5. INICIO DE LA APLICACIÓN

if __name__ == '__main__': 
    # Siempre ejecuta la aplicación en modo debug, pero en producción úsalo como: app.run()
    app.run(debug=True)